/********************************************************************************
** Form generated from reading UI file 'personalinfomanager.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PERSONALINFOMANAGER_H
#define UI_PERSONALINFOMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PersonalInfoManager
{
public:

    void setupUi(QWidget *PersonalInfoManager)
    {
        if (PersonalInfoManager->objectName().isEmpty())
            PersonalInfoManager->setObjectName(QString::fromUtf8("PersonalInfoManager"));
        PersonalInfoManager->resize(400, 300);

        retranslateUi(PersonalInfoManager);

        QMetaObject::connectSlotsByName(PersonalInfoManager);
    } // setupUi

    void retranslateUi(QWidget *PersonalInfoManager)
    {
        PersonalInfoManager->setWindowTitle(QCoreApplication::translate("PersonalInfoManager", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PersonalInfoManager: public Ui_PersonalInfoManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PERSONALINFOMANAGER_H
