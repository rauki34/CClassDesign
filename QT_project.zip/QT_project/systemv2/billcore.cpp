#include "billcore.h"

BillCore::BillCore()
{

}
