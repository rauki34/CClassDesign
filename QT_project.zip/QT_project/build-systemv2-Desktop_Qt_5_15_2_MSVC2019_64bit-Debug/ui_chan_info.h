/********************************************************************************
** Form generated from reading UI file 'chan_info.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHAN_INFO_H
#define UI_CHAN_INFO_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chan_info
{
public:
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLineEdit *code;
    QVBoxLayout *verticalLayout;
    QPushButton *change;
    QPushButton *delete_2;
    QPushButton *back;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QLineEdit *name;
    QLabel *label_5;
    QLineEdit *major;
    QLabel *label_3;
    QComboBox *gender;
    QLabel *label_4;
    QDateEdit *date;
    QLabel *label_6;
    QLineEdit *hobby;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *chan_info)
    {
        if (chan_info->objectName().isEmpty())
            chan_info->setObjectName(QString::fromUtf8("chan_info"));
        chan_info->resize(519, 436);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        chan_info->setWindowIcon(icon);
        gridLayout_3 = new QGridLayout(chan_info);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_2 = new QLabel(chan_info);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        code = new QLineEdit(chan_info);
        code->setObjectName(QString::fromUtf8("code"));
        code->setMaximumSize(QSize(16777215, 50));
        code->setMaxLength(10);

        gridLayout->addWidget(code, 0, 1, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        change = new QPushButton(chan_info);
        change->setObjectName(QString::fromUtf8("change"));
        change->setMaximumSize(QSize(16777215, 30));

        verticalLayout->addWidget(change);

        delete_2 = new QPushButton(chan_info);
        delete_2->setObjectName(QString::fromUtf8("delete_2"));
        delete_2->setMaximumSize(QSize(16777215, 30));

        verticalLayout->addWidget(delete_2);

        back = new QPushButton(chan_info);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));

        verticalLayout->addWidget(back);


        gridLayout->addLayout(verticalLayout, 1, 1, 1, 1);


        gridLayout_3->addLayout(gridLayout, 2, 0, 1, 1);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(chan_info);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        name = new QLineEdit(chan_info);
        name->setObjectName(QString::fromUtf8("name"));
        name->setMaximumSize(QSize(16777215, 50));
        name->setMaxLength(20);

        gridLayout_2->addWidget(name, 0, 1, 1, 1);

        label_5 = new QLabel(chan_info);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(label_5, 1, 0, 1, 1);

        major = new QLineEdit(chan_info);
        major->setObjectName(QString::fromUtf8("major"));
        major->setMaximumSize(QSize(16777215, 50));
        major->setMaxLength(20);

        gridLayout_2->addWidget(major, 1, 1, 1, 1);

        label_3 = new QLabel(chan_info);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        gender = new QComboBox(chan_info);
        gender->addItem(QString());
        gender->addItem(QString());
        gender->setObjectName(QString::fromUtf8("gender"));
        gender->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(gender, 2, 1, 1, 1);

        label_4 = new QLabel(chan_info);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(label_4, 3, 0, 1, 1);

        date = new QDateEdit(chan_info);
        date->setObjectName(QString::fromUtf8("date"));
        date->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(date, 3, 1, 1, 1);

        label_6 = new QLabel(chan_info);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(label_6, 4, 0, 1, 1);

        hobby = new QLineEdit(chan_info);
        hobby->setObjectName(QString::fromUtf8("hobby"));
        hobby->setMaximumSize(QSize(16777215, 50));
        hobby->setMaxLength(20);

        gridLayout_2->addWidget(hobby, 4, 1, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_3->addItem(verticalSpacer, 1, 0, 1, 1);


        retranslateUi(chan_info);

        QMetaObject::connectSlotsByName(chan_info);
    } // setupUi

    void retranslateUi(QWidget *chan_info)
    {
        chan_info->setWindowTitle(QCoreApplication::translate("chan_info", "\344\270\252\344\272\272\344\277\241\346\201\257\344\277\256\346\224\271", nullptr));
        label_2->setText(QCoreApplication::translate("chan_info", "\345\255\246\345\217\267", nullptr));
        code->setPlaceholderText(QCoreApplication::translate("chan_info", "\350\257\267\350\276\223\345\205\245\345\255\246\345\217\267\346\235\245\350\277\233\350\241\214\346\223\215\344\275\234", nullptr));
        change->setText(QCoreApplication::translate("chan_info", "\344\277\256\346\224\271", nullptr));
        delete_2->setText(QCoreApplication::translate("chan_info", "\345\210\240\351\231\244", nullptr));
        back->setText(QCoreApplication::translate("chan_info", "\350\277\224\345\233\236", nullptr));
        label->setText(QCoreApplication::translate("chan_info", "\345\247\223\345\220\215", nullptr));
        label_5->setText(QCoreApplication::translate("chan_info", "\344\270\223\344\270\232", nullptr));
        label_3->setText(QCoreApplication::translate("chan_info", "\346\200\247\345\210\253", nullptr));
        gender->setItemText(0, QCoreApplication::translate("chan_info", "\347\224\267", nullptr));
        gender->setItemText(1, QCoreApplication::translate("chan_info", "\345\245\263", nullptr));

        label_4->setText(QCoreApplication::translate("chan_info", "\345\207\272\347\224\237\345\271\264\346\234\210", nullptr));
        label_6->setText(QCoreApplication::translate("chan_info", "\347\210\261\345\245\275", nullptr));
    } // retranslateUi

};

namespace Ui {
    class chan_info: public Ui_chan_info {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAN_INFO_H
