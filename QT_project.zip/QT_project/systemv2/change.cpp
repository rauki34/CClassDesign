#include "change.h"
#include "ui_change.h"
#include "functions.h"
#include "chan_info.h"
#include "billrecord.h"
#include "supersocre.h"

change::change(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::change)
{
    ui->setupUi(this);
}

change::~change()
{
    delete ui;
}
//返回主菜单
void change::on_back_clicked()
{
    functions *w = new functions;
    w->show();
    this->hide();
}

//个人信息修改
void change::on_stu_info_clicked()
{
    chan_info *w = new chan_info;
    w->show();
    this->hide();
}

//消费记录修改
void change::on_consume_clicked()
{
    billrecord *w = new billrecord;
    w->show();
    this->hide();
}

//成绩修改
void change::on_score_clicked()
{
    supersocre *w = new supersocre;
    w->show();
    this->hide();
}

