#include "search.h"
#include "ui_search.h"
#include "functions.h"
#include "sear_info.h"
#include "billrecord.h"
#include "supersocre.h"

search::search(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::search)
{
    ui->setupUi(this);
}

search::~search()
{
    delete ui;
}
//个人信息查询
void search::on_per_info_clicked()
{
    sear_info *w = new sear_info;
    w->show();
    this->hide();
}

//消费记录查询
void search::on_consume_clicked()
{
    billrecord *w = new billrecord;
    w->show();
    this->hide();
}

//成绩查询
void search::on_score_clicked()
{
    supersocre *w = new supersocre;
    w->show();
    this->hide();
}

//返回
void search::on_back_clicked()
{
    functions *w = new functions;
    w->show();
    this->hide();
}

