#ifndef CHAN_INFO_H
#define CHAN_INFO_H

#include <QWidget>
#include <QFile>
#include <QMessageBox>
#include <QtDebug>
#include <QVector>
#include "studentinfo.h"

namespace Ui {
class chan_info;
}

class chan_info : public QWidget
{
    Q_OBJECT

public:
    explicit chan_info(QWidget *parent = nullptr);
    ~chan_info();

private slots:
    void on_back_clicked();

    void on_change_clicked();

    void on_delete_2_clicked();

private:
    Ui::chan_info *ui;
};

#endif // CHAN_INFO_H
