/********************************************************************************
** Form generated from reading UI file 'search.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCH_H
#define UI_SEARCH_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_search
{
public:
    QGridLayout *gridLayout_2;
    QPushButton *back;
    QWidget *widget;
    QGridLayout *gridLayout;
    QPushButton *per_info;
    QPushButton *consume;
    QPushButton *score;

    void setupUi(QWidget *search)
    {
        if (search->objectName().isEmpty())
            search->setObjectName(QString::fromUtf8("search"));
        search->resize(432, 344);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        search->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(search);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        back = new QPushButton(search);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));

        gridLayout_2->addWidget(back, 1, 1, 1, 1);

        widget = new QWidget(search);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        per_info = new QPushButton(widget);
        per_info->setObjectName(QString::fromUtf8("per_info"));
        per_info->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(per_info, 0, 0, 1, 1);

        consume = new QPushButton(widget);
        consume->setObjectName(QString::fromUtf8("consume"));
        consume->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(consume, 1, 0, 1, 1);

        score = new QPushButton(widget);
        score->setObjectName(QString::fromUtf8("score"));
        score->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(score, 2, 0, 1, 1);


        gridLayout_2->addWidget(widget, 0, 0, 1, 2);


        retranslateUi(search);

        QMetaObject::connectSlotsByName(search);
    } // setupUi

    void retranslateUi(QWidget *search)
    {
        search->setWindowTitle(QCoreApplication::translate("search", "\346\237\245\346\211\276\345\255\246\347\224\237\344\277\241\346\201\257", nullptr));
        back->setText(QCoreApplication::translate("search", "\344\270\273\350\217\234\345\215\225", nullptr));
        per_info->setText(QCoreApplication::translate("search", "\344\270\252\344\272\272\344\277\241\346\201\257", nullptr));
        consume->setText(QCoreApplication::translate("search", "\346\266\210\350\264\271\350\256\260\345\275\225", nullptr));
        score->setText(QCoreApplication::translate("search", "\346\210\220\347\273\251\344\277\241\346\201\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class search: public Ui_search {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCH_H
