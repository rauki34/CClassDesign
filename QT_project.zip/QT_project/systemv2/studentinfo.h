#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include <QString>


class StudentInfo
{
private:
    QString name,code,hobby,birth,gender,major;
public:
    StudentInfo();
    StudentInfo(QString tname, QString tcode, QString thobby, QString tbirth, QString tgender, QString tmajor){
        name = tname;
        code = tcode;
        gender = tgender;
        major = tmajor;
        birth = tbirth;
        hobby = thobby;
    }
    QString getCode(){
        return code;
    }
    QString getName(){
        return name;
    }
    QString getGender(){
        return gender;
    }
    QString getBirth(){
        return birth;
    }
    QString getHobby(){
        return hobby;
    }
    QString getMajor(){
        return major;
    }
    void setCode(QString tcode){
        code = tcode;
    }
    void setName(QString tname){
        name = tname;
    }
    void setGender(QString tgender){
        gender = tgender;
    }
    void setHobby(QString thobby){
        hobby = thobby;
    }
    void setBirth(QString tbirth){
        birth = tbirth;
    }
    void setMajor(QString tmajor){
        major = tmajor;
    }
};

#endif // STUDENTINFO_H
