/********************************************************************************
** Form generated from reading UI file 'newstu.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWSTU_H
#define UI_NEWSTU_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newstu
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer;
    QPushButton *addnew;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *name;
    QLineEdit *code;
    QLineEdit *major;
    QComboBox *gender;
    QDateEdit *date;
    QLineEdit *hobby;
    QPushButton *back;

    void setupUi(QWidget *newstu)
    {
        if (newstu->objectName().isEmpty())
            newstu->setObjectName(QString::fromUtf8("newstu"));
        newstu->resize(514, 427);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        newstu->setWindowIcon(icon);
        gridLayout = new QGridLayout(newstu);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(newstu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label);

        label_2 = new QLabel(newstu);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label_2);

        label_5 = new QLabel(newstu);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label_5);

        label_3 = new QLabel(newstu);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(newstu);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label_4);

        label_6 = new QLabel(newstu);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMaximumSize(QSize(16777215, 50));

        verticalLayout->addWidget(label_6);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 3, 1, 1);

        addnew = new QPushButton(newstu);
        addnew->setObjectName(QString::fromUtf8("addnew"));
        addnew->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(addnew, 1, 2, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        name = new QLineEdit(newstu);
        name->setObjectName(QString::fromUtf8("name"));
        name->setMaximumSize(QSize(16777215, 50));
        name->setMaxLength(20);

        verticalLayout_2->addWidget(name);

        code = new QLineEdit(newstu);
        code->setObjectName(QString::fromUtf8("code"));
        code->setMaximumSize(QSize(16777215, 50));
        code->setMaxLength(10);

        verticalLayout_2->addWidget(code);

        major = new QLineEdit(newstu);
        major->setObjectName(QString::fromUtf8("major"));
        major->setMaximumSize(QSize(16777215, 50));
        major->setMaxLength(20);

        verticalLayout_2->addWidget(major);

        gender = new QComboBox(newstu);
        gender->addItem(QString());
        gender->addItem(QString());
        gender->setObjectName(QString::fromUtf8("gender"));
        gender->setMaximumSize(QSize(16777215, 50));

        verticalLayout_2->addWidget(gender);

        date = new QDateEdit(newstu);
        date->setObjectName(QString::fromUtf8("date"));
        date->setMaximumSize(QSize(16777215, 50));

        verticalLayout_2->addWidget(date);

        hobby = new QLineEdit(newstu);
        hobby->setObjectName(QString::fromUtf8("hobby"));
        hobby->setMaximumSize(QSize(16777215, 50));
        hobby->setMaxLength(20);

        verticalLayout_2->addWidget(hobby);


        gridLayout->addLayout(verticalLayout_2, 0, 2, 1, 1);

        back = new QPushButton(newstu);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(back, 1, 4, 1, 1);


        retranslateUi(newstu);

        QMetaObject::connectSlotsByName(newstu);
    } // setupUi

    void retranslateUi(QWidget *newstu)
    {
        newstu->setWindowTitle(QCoreApplication::translate("newstu", "\346\267\273\345\212\240\345\255\246\347\224\237\344\277\241\346\201\257", nullptr));
        label->setText(QCoreApplication::translate("newstu", "\345\247\223\345\220\215", nullptr));
        label_2->setText(QCoreApplication::translate("newstu", "\345\255\246\345\217\267", nullptr));
        label_5->setText(QCoreApplication::translate("newstu", "\344\270\223\344\270\232", nullptr));
        label_3->setText(QCoreApplication::translate("newstu", "\346\200\247\345\210\253", nullptr));
        label_4->setText(QCoreApplication::translate("newstu", "\345\207\272\347\224\237\345\271\264\346\234\210", nullptr));
        label_6->setText(QCoreApplication::translate("newstu", "\347\210\261\345\245\275", nullptr));
        addnew->setText(QCoreApplication::translate("newstu", "\346\267\273\345\212\240", nullptr));
        gender->setItemText(0, QCoreApplication::translate("newstu", "\347\224\267", nullptr));
        gender->setItemText(1, QCoreApplication::translate("newstu", "\345\245\263", nullptr));

        back->setText(QCoreApplication::translate("newstu", "\344\270\273\350\217\234\345\215\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class newstu: public Ui_newstu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWSTU_H
