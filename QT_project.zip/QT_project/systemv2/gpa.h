#ifndef GPA_H
#define GPA_H
#include <QString>

class GPA
{
private: QString name,id,subject,score;
public:
    GPA();
    GPA(QString tname, QString tid, QString tsubject, QString tscore){
        name = tname;
        id = tid;
        subject = tsubject;
        score = tscore;
    }
    QString getName(){
        return name;
    }
    QString getId(){
        return id;
    }
    QString getSubject(){
        return subject;
    }
    QString getScore(){
        return score;
    }
    void setId(QString tid){
        id = tid;
    }
    void setName(QString tname){
        name = tname;
    }
    void setSubject(QString tsubject){
        subject = tsubject;
    }
    void setScore(QString tscore){
        score = tscore;
    }
};

#endif // GPA_H
