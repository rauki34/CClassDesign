#ifndef BILLRECORD_H
#define BILLRECORD_H

#include <QWidget>
#include <QMessageBox>
#include <QtDebug>
#include <QFile>
#include <QDateEdit>
#include <QComboBox>
#include <QString>

namespace Ui {
class billrecord;
}

class billrecord : public QWidget
{
    Q_OBJECT

public:
    explicit billrecord(QWidget *parent = nullptr);
    ~billrecord();

private slots:
    void on_memu_clicked();

    void on_btn_add_clicked();

    void on_btn_search_clicked();

    void on_btn_change_clicked();

    void on_btn_delete_clicked();

private:
    Ui::billrecord *ui;
};

#endif // BILLRECORD_H
