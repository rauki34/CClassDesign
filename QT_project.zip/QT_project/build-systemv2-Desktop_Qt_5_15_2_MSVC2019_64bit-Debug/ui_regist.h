/********************************************************************************
** Form generated from reading UI file 'regist.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGIST_H
#define UI_REGIST_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_regist
{
public:
    QGridLayout *gridLayout_2;
    QWidget *widget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *username;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *passw1;
    QLabel *label_2;
    QLineEdit *passw2;
    QPushButton *regis;
    QPushButton *bcak;

    void setupUi(QWidget *regist)
    {
        if (regist->objectName().isEmpty())
            regist->setObjectName(QString::fromUtf8("regist"));
        regist->resize(800, 400);
        regist->setMinimumSize(QSize(800, 400));
        regist->setMaximumSize(QSize(800, 400));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        regist->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(regist);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        widget = new QWidget(regist);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 50));
        label->setPixmap(QPixmap(QString::fromUtf8(":/log_ic01.png")));

        horizontalLayout->addWidget(label);

        username = new QLineEdit(widget);
        username->setObjectName(QString::fromUtf8("username"));
        username->setMaximumSize(QSize(16777215, 50));
        username->setMaxLength(10);

        horizontalLayout->addWidget(username);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/log_ic02.png")));

        horizontalLayout_2->addWidget(label_3);

        passw1 = new QLineEdit(widget);
        passw1->setObjectName(QString::fromUtf8("passw1"));
        passw1->setMaximumSize(QSize(16777215, 50));
        passw1->setMaxLength(8);

        horizontalLayout_2->addWidget(passw1);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 2);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(0, 0));
        label_2->setMaximumSize(QSize(16777215, 50));
        QFont font;
        font.setPointSize(20);
        label_2->setFont(font);
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/log_ic02.png")));
        label_2->setScaledContents(false);
        label_2->setMargin(0);
        label_2->setIndent(-1);

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        passw2 = new QLineEdit(widget);
        passw2->setObjectName(QString::fromUtf8("passw2"));
        passw2->setMaximumSize(QSize(16777215, 50));
        passw2->setMaxLength(8);

        gridLayout->addWidget(passw2, 2, 1, 1, 1);


        gridLayout_2->addWidget(widget, 0, 0, 1, 2);

        regis = new QPushButton(regist);
        regis->setObjectName(QString::fromUtf8("regis"));

        gridLayout_2->addWidget(regis, 1, 0, 1, 1);

        bcak = new QPushButton(regist);
        bcak->setObjectName(QString::fromUtf8("bcak"));
        bcak->setCheckable(false);

        gridLayout_2->addWidget(bcak, 1, 1, 1, 1);


        retranslateUi(regist);

        QMetaObject::connectSlotsByName(regist);
    } // setupUi

    void retranslateUi(QWidget *regist)
    {
        regist->setWindowTitle(QCoreApplication::translate("regist", "\346\263\250\345\206\214", nullptr));
        label->setText(QString());
        username->setPlaceholderText(QCoreApplication::translate("regist", "\350\257\267\350\276\223\345\205\245\347\224\250\346\210\267\345\220\215", nullptr));
        label_3->setText(QString());
        passw1->setPlaceholderText(QCoreApplication::translate("regist", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201\357\274\2108\344\275\215\357\274\211", nullptr));
        label_2->setText(QString());
        passw2->setPlaceholderText(QCoreApplication::translate("regist", "\350\257\267\345\206\215\346\254\241\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        regis->setText(QCoreApplication::translate("regist", "\346\263\250\345\206\214", nullptr));
        bcak->setText(QCoreApplication::translate("regist", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class regist: public Ui_regist {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGIST_H
