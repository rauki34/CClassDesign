/********************************************************************************
** Form generated from reading UI file 'memu.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEMU_H
#define UI_MEMU_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_memu
{
public:
    QGridLayout *gridLayout_2;
    QLabel *label;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLineEdit *password;
    QSpacerItem *horizontalSpacer;
    QLineEdit *user;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *checkBox;
    QHBoxLayout *horizontalLayout;
    QPushButton *btn_login;
    QPushButton *btn_regis;

    void setupUi(QWidget *memu)
    {
        if (memu->objectName().isEmpty())
            memu->setObjectName(QString::fromUtf8("memu"));
        memu->setEnabled(true);
        memu->resize(800, 400);
        memu->setMinimumSize(QSize(800, 400));
        memu->setMaximumSize(QSize(800, 400));
        memu->setMouseTracking(false);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        memu->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(memu);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(memu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 60));
        QFont font;
        font.setPointSize(20);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        widget = new QWidget(memu);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        password = new QLineEdit(widget);
        password->setObjectName(QString::fromUtf8("password"));
        password->setMaximumSize(QSize(16777215, 40));
        password->setMaxLength(8);
        password->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(password, 2, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(100, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 2, 1, 1);

        user = new QLineEdit(widget);
        user->setObjectName(QString::fromUtf8("user"));
        user->setMaximumSize(QSize(16777215, 40));
        user->setMaxLength(10);

        gridLayout->addWidget(user, 1, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(100, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 1, 0, 1, 1);

        checkBox = new QCheckBox(widget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setEnabled(true);
        checkBox->setMaximumSize(QSize(16777215, 40));
        checkBox->setChecked(false);
        checkBox->setTristate(false);

        gridLayout->addWidget(checkBox, 2, 2, 1, 1);


        gridLayout_2->addWidget(widget, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(30, -1, 30, -1);
        btn_login = new QPushButton(memu);
        btn_login->setObjectName(QString::fromUtf8("btn_login"));
        btn_login->setMaximumSize(QSize(16777215, 40));

        horizontalLayout->addWidget(btn_login);

        btn_regis = new QPushButton(memu);
        btn_regis->setObjectName(QString::fromUtf8("btn_regis"));
        btn_regis->setMaximumSize(QSize(16777215, 40));

        horizontalLayout->addWidget(btn_regis);


        gridLayout_2->addLayout(horizontalLayout, 2, 0, 1, 1);


        retranslateUi(memu);

        QMetaObject::connectSlotsByName(memu);
    } // setupUi

    void retranslateUi(QWidget *memu)
    {
        memu->setWindowTitle(QCoreApplication::translate("memu", "\347\231\273\345\275\225", nullptr));
#if QT_CONFIG(tooltip)
        memu->setToolTip(QCoreApplication::translate("memu", "\350\277\231\346\230\257\347\231\273\345\275\225\347\252\227\345\217\243", nullptr));
#endif // QT_CONFIG(tooltip)
        label->setText(QCoreApplication::translate("memu", "\344\270\252\344\272\272\344\277\241\346\201\257\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        password->setPlaceholderText(QCoreApplication::translate("memu", "\345\257\206\347\240\201", nullptr));
        user->setText(QString());
        user->setPlaceholderText(QCoreApplication::translate("memu", "\347\224\250\346\210\267\345\220\215", nullptr));
        checkBox->setText(QCoreApplication::translate("memu", "\346\230\276\347\244\272", nullptr));
        btn_login->setText(QCoreApplication::translate("memu", "\347\231\273\345\275\225", nullptr));
        btn_regis->setText(QCoreApplication::translate("memu", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class memu: public Ui_memu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEMU_H
