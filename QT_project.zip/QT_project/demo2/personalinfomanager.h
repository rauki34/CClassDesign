#ifndef PERSONALINFOMANAGER_H
#define PERSONALINFOMANAGER_H

#include <QWidget>

namespace Ui {
class PersonalInfoManager;
}

class PersonalInfoManager : public QWidget
{
    Q_OBJECT

public:
    explicit PersonalInfoManager(QWidget *parent = nullptr);
    ~PersonalInfoManager();

private:
    Ui::PersonalInfoManager *ui;
};

#endif // PERSONALINFOMANAGER_H
