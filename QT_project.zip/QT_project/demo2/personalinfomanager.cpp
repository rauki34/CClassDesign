#include <QtWidgets>

class PersonalInfoManager : public QDialog {
    Q_OBJECT

public:
    PersonalInfoManager(QWidget* parent = nullptr) : QDialog(parent) {
        // 创建UI界面组件
        nameLabel = new QLabel("姓名:");
        nameLineEdit = new QLineEdit;
        ageLabel = new QLabel("年龄:");
        ageSpinBox = new QSpinBox;
        addressLabel = new QLabel("地址:");
        addressTextEdit = new QTextEdit;
        saveButton = new QPushButton("保存");

        // 创建布局管理器
        QVBoxLayout* layout = new QVBoxLayout;
        layout->addWidget(nameLabel);
        layout->addWidget(nameLineEdit);
        layout->addWidget(ageLabel);
        layout->addWidget(ageSpinBox);
        layout->addWidget(addressLabel);
        layout->addWidget(addressTextEdit);
        layout->addWidget(saveButton);

        // 设置布局
        setLayout(layout);

        // 连接保存按钮的点击事件
        connect(saveButton, &QPushButton::clicked, this, &PersonalInfoManager::saveInfo);
    }

private slots:
    void saveInfo() {
        // 获取输入的个人信息
        QString name = nameLineEdit->text();
        int age = ageSpinBox->value();
        QString address = addressTextEdit->toPlainText();

        // 在这里可以将个人信息保存到数据库或做其他操作

        // 显示保存成功提示框
        QMessageBox::information(this, "保存成功", "个人信息已保存！");
    }

private:
    QLabel* nameLabel;
    QLineEdit* nameLineEdit;
    QLabel* ageLabel;
    QSpinBox* ageSpinBox;
    QLabel* addressLabel;
    QTextEdit* addressTextEdit;
    QPushButton* saveButton;
};

int main(int argc, char** argv) {
    QApplication app(argc, argv);

    // 创建个人信息管理系统窗口
    PersonalInfoManager manager;
    manager.show();

    return app.exec();
}

#include "main.moc"
