#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <QWidget>

namespace Ui {
class functions;
}

class functions : public QWidget
{
    Q_OBJECT

public:
    explicit functions(QWidget *parent = nullptr);
    ~functions();

private slots:
    void on_changeinf_2_clicked();

    void on_addstu_clicked();

    void on_search_clicked();

    void on_changeinf_clicked();

private:
    Ui::functions *ui;
};

#endif // FUNCTIONS_H
