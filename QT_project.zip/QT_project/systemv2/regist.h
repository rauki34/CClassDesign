#ifndef REGIST_H
#define REGIST_H
#include <QtDebug>
#include <QString>
#include <QFile>
#include <QWidget>

namespace Ui {
class regist;
}

class regist : public QWidget
{
    Q_OBJECT

public:
    explicit regist(QWidget *parent = nullptr);
    ~regist();

private slots:
    void on_regis_clicked();

    void on_bcak_clicked();

private:
    Ui::regist *ui;
};

#endif // REGIST_H
