#ifndef NEWSTU_H
#define NEWSTU_H
#include <QMessageBox>
#include <QtDebug>
#include <QFile>
#include <QDateEdit>
#include <QComboBox>
#include <QWidget>
#include <QString>

namespace Ui {
class newstu;
}

class newstu : public QWidget
{
    Q_OBJECT

public:
    explicit newstu(QWidget *parent = nullptr);
    ~newstu();

private slots:
    void on_back_clicked();

    void on_addnew_clicked();

private:
    Ui::newstu *ui;
};

#endif // NEWSTU_H
