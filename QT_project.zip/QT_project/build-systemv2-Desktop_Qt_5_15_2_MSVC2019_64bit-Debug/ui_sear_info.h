/********************************************************************************
** Form generated from reading UI file 'sear_info.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEAR_INFO_H
#define UI_SEAR_INFO_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sear_info
{
public:
    QGridLayout *gridLayout_3;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QLabel *showmajor;
    QLabel *showbirth;
    QLabel *showgender;
    QLabel *showname;
    QLabel *showhobby;
    QLineEdit *lineEdit;
    QPushButton *btn_search;
    QPushButton *back;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *gender;
    QLabel *name;
    QLabel *birth;
    QLabel *major;
    QLabel *code;
    QLabel *hobby;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *sear_info)
    {
        if (sear_info->objectName().isEmpty())
            sear_info->setObjectName(QString::fromUtf8("sear_info"));
        sear_info->resize(400, 300);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        sear_info->setWindowIcon(icon);
        gridLayout_3 = new QGridLayout(sear_info);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        widget_2 = new QWidget(sear_info);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        showmajor = new QLabel(widget_2);
        showmajor->setObjectName(QString::fromUtf8("showmajor"));
        showmajor->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(showmajor, 5, 0, 1, 1);

        showbirth = new QLabel(widget_2);
        showbirth->setObjectName(QString::fromUtf8("showbirth"));
        showbirth->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(showbirth, 6, 0, 1, 1);

        showgender = new QLabel(widget_2);
        showgender->setObjectName(QString::fromUtf8("showgender"));
        showgender->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(showgender, 4, 0, 1, 1);

        showname = new QLabel(widget_2);
        showname->setObjectName(QString::fromUtf8("showname"));
        showname->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(showname, 3, 0, 1, 1);

        showhobby = new QLabel(widget_2);
        showhobby->setObjectName(QString::fromUtf8("showhobby"));
        showhobby->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(showhobby, 7, 0, 1, 1);

        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMaximumSize(QSize(16777215, 50));
        lineEdit->setMaxLength(10);

        gridLayout_2->addWidget(lineEdit, 2, 0, 1, 1);


        gridLayout_3->addWidget(widget_2, 0, 1, 1, 3);

        btn_search = new QPushButton(sear_info);
        btn_search->setObjectName(QString::fromUtf8("btn_search"));
        btn_search->setMaximumSize(QSize(16777215, 30));

        gridLayout_3->addWidget(btn_search, 1, 0, 1, 2);

        back = new QPushButton(sear_info);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));

        gridLayout_3->addWidget(back, 1, 3, 1, 1);

        widget = new QWidget(sear_info);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gender = new QLabel(widget);
        gender->setObjectName(QString::fromUtf8("gender"));
        gender->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(gender, 2, 0, 1, 1);

        name = new QLabel(widget);
        name->setObjectName(QString::fromUtf8("name"));
        name->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(name, 1, 0, 1, 1);

        birth = new QLabel(widget);
        birth->setObjectName(QString::fromUtf8("birth"));
        birth->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(birth, 4, 0, 1, 1);

        major = new QLabel(widget);
        major->setObjectName(QString::fromUtf8("major"));
        major->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(major, 3, 0, 1, 1);

        code = new QLabel(widget);
        code->setObjectName(QString::fromUtf8("code"));
        code->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(code, 0, 0, 1, 1);

        hobby = new QLabel(widget);
        hobby->setObjectName(QString::fromUtf8("hobby"));
        hobby->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(hobby, 5, 0, 1, 1);


        gridLayout_3->addWidget(widget, 0, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 1, 2, 1, 1);


        retranslateUi(sear_info);

        QMetaObject::connectSlotsByName(sear_info);
    } // setupUi

    void retranslateUi(QWidget *sear_info)
    {
        sear_info->setWindowTitle(QCoreApplication::translate("sear_info", "\345\255\246\347\224\237\344\277\241\346\201\257\346\237\245\350\257\242", nullptr));
        showmajor->setText(QCoreApplication::translate("sear_info", "NULL", nullptr));
        showbirth->setText(QCoreApplication::translate("sear_info", "NULL", nullptr));
        showgender->setText(QCoreApplication::translate("sear_info", "NULL", nullptr));
        showname->setText(QCoreApplication::translate("sear_info", "NULL", nullptr));
        showhobby->setText(QCoreApplication::translate("sear_info", "NULL", nullptr));
        lineEdit->setText(QString());
        lineEdit->setPlaceholderText(QCoreApplication::translate("sear_info", "\350\257\267\350\276\223\345\205\245", nullptr));
        btn_search->setText(QCoreApplication::translate("sear_info", "\346\237\245\350\257\242", nullptr));
        back->setText(QCoreApplication::translate("sear_info", "\350\277\224\345\233\236", nullptr));
        gender->setText(QCoreApplication::translate("sear_info", "\346\200\247\345\210\253", nullptr));
        name->setText(QCoreApplication::translate("sear_info", "\345\247\223\345\220\215", nullptr));
        birth->setText(QCoreApplication::translate("sear_info", "\345\207\272\347\224\237\345\271\264\346\234\210", nullptr));
        major->setText(QCoreApplication::translate("sear_info", "\344\270\223\344\270\232", nullptr));
        code->setText(QCoreApplication::translate("sear_info", "\345\255\246\345\217\267", nullptr));
        hobby->setText(QCoreApplication::translate("sear_info", "\347\210\261\345\245\275", nullptr));
    } // retranslateUi

};

namespace Ui {
    class sear_info: public Ui_sear_info {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEAR_INFO_H
