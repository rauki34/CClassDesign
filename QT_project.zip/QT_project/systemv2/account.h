#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <QString>

class Account
{
private: QString user,password;
public:
    Account();
    Account(QString tuser, QString tpassword){
        user = tuser;
        password = tpassword;
    }
    QString getUser(){
        return user;
    }
    QString getPassword(){
        return password;
    }
};

#endif // ACCOUNT_H
