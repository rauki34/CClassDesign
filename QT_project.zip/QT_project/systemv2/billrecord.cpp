#include "billrecord.h"
#include "ui_billrecord.h"
#include "functions.h"
#include "billcore.h"

billrecord::billrecord(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::billrecord)
{
    ui->setupUi(this);
}

billrecord::~billrecord()
{
    delete ui;
}
//返回主菜单
void billrecord::on_memu_clicked()
{
    functions *w = new functions;
    w->show();
    this->hide();
}

//添加消费记录
void billrecord::on_btn_add_clicked()
{
    QString id = ui->ad_id->text();
    QString item = ui->ad_item->text();
    QString charge = ui->ad_charge->text();
    QString date = ui->ad_date->text();
    if(ui->ad_id->text() == "" || ui->ad_item->text() == "" || ui->ad_charge->text() == ""){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QFile file("bill.txt");
    //实例化一个QFile file为我们的数据文件bill.txt
    file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Append);
    //open()可以用来打开文件这里QIODevice::WriteOnly代表将文件以只写的方式打开
    //QIODevice::Text代表我们打开的是文本文件，QIODevice::Text会对end-of-line结束符进行转译
    //QIODevice::Append以追加的方式打开，新增加的内容将被追加到文件末尾
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    QTextStream out(&file);
    //QTextStream可以进行一些基本的文本读写，比如QString int char之类的数据QDataStream可以进行一个如QMap QPoint之类数据的读写。
    out << id << " " <<  date << " " << item << " " << charge << endl;
    //将我们刚刚获取的数据写入文件
    file.close();
    QMessageBox::about(this, "反馈", "插入成功");
    billrecord *w = new billrecord;
    w->show();
    this->hide();
}

//查询消费记录
void billrecord::on_btn_search_clicked()
{
    if(ui->sear_id->text() == ""){
        QMessageBox::about(this, "警告", "编号不能为空");
        return;
    }
    QFile file("bill.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<BillCore> BILL;
    //数据类型为BillCore的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString id,date,item,charge;
        inp >> id >> date >>  item >> charge;
        BILL.push_back(BillCore(id,date,item,charge));
        //调用之前建立的构造函数实例化一个BillCore对象并将其加入BILL
    }
    BILL.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString id = ui->sear_id->text();
    bool flag = false;
    for(auto i : BILL){
        if(i.getId() == id){
            ui->s_date->setText(i.getDate());
            ui->s_item->setText(i.getItem());
            ui->s_charge->setText(i.getCharge());
            flag = true;
            break;
        }
    }
    if(!flag){
        QMessageBox::about(this, "反馈", "编号不存在！");
    }
    ui->sear_id->clear();
}

//修改消费记录
void billrecord::on_btn_change_clicked()
{
    if(ui->c_id->text() == "" || ui->c_item->text() == "" || ui->c_charge->text() == ""){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QFile file("bill.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<BillCore> BILL;
    //数据类型为BillCore的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString id,date,item,charge;
        inp >> id >> date >>  item >> charge;
        BILL.push_back(BillCore(id,date,item,charge));
        //调用之前建立的构造函数实例化一个BillCore对象并将其加入BILL
    }
    BILL.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString id = ui->c_id->text();
    QString item = ui->c_item->text();
    QString charge = ui->c_charge->text();
    QString date = ui->c_date->text();
    bool flag = false;
    for(QVector<BillCore>::iterator it = BILL.begin(); it != BILL.end(); it++){
        if(it->getId() == id){
            it->setDate(date);
            it->setItem(item);
            it->setCharge(charge);
            flag = true;
        }
    }
    if(flag){   //如果进行过修改，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "修改成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : BILL){
            out << i.getId() << " " << i.getDate() << " " << i.getItem() << " " << i.getCharge() << endl;
        }
        file.close();
    }else{
        //如果没有进行修改，弹出不存在对话框
        QMessageBox::about(this, "反馈", "编号不存在！");
    }
    //关闭文件
    billrecord *w = new billrecord;
    w->show();
    this->hide();
    //初始化
}

//删除消费记录
void billrecord::on_btn_delete_clicked()
{
    QVector<BillCore> BILL;
    if(ui->c_id->text() == ""){
        QMessageBox::about(this, "警告", "编号不能为空");
        return;
    }
    QFile file("bill.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    while(!inp.atEnd()){ //读到文件结尾
        QString id,date,item,charge;
        inp >> id >> date >>  item >> charge;
        BILL.push_back(BillCore(id,date,item,charge));
        //调用之前建立的构造函数实例化一个BillCore对象并将其加入BILL
    }
    BILL.pop_back();
    //扔掉最后的无用数据
    file.close();
    QString id = ui->c_id->text();
    bool flag = false;
    for(QVector<BillCore>::iterator it = BILL.begin(); it != BILL.end(); it++){
        if(it->getId() == id){
            BILL.erase(it);//迭代器遍历BILL找到对应就删除
            flag = true;
        }
    }
    if(flag){   //如果进行过修改，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "删除成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : BILL){
            out << i.getId() << " " << i.getDate() << " " << i.getItem() << " " << i.getCharge() << endl;
        }
        file.close();
    }else{
        //如果没有进行删除，弹出不存在对话框
        QMessageBox::about(this, "反馈", "编号不存在！");
    }
    ui->c_id->clear();
}

