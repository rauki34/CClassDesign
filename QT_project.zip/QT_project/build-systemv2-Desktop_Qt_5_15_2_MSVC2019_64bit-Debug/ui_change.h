/********************************************************************************
** Form generated from reading UI file 'change.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGE_H
#define UI_CHANGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_change
{
public:
    QGridLayout *gridLayout;
    QPushButton *back;
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QPushButton *stu_info;
    QPushButton *consume;
    QPushButton *score;

    void setupUi(QWidget *change)
    {
        if (change->objectName().isEmpty())
            change->setObjectName(QString::fromUtf8("change"));
        change->resize(442, 344);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        change->setWindowIcon(icon);
        gridLayout = new QGridLayout(change);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        back = new QPushButton(change);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(back, 1, 1, 1, 1);

        widget = new QWidget(change);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        stu_info = new QPushButton(widget);
        stu_info->setObjectName(QString::fromUtf8("stu_info"));
        stu_info->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(stu_info, 0, 0, 1, 1);

        consume = new QPushButton(widget);
        consume->setObjectName(QString::fromUtf8("consume"));
        consume->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(consume, 1, 0, 1, 1);

        score = new QPushButton(widget);
        score->setObjectName(QString::fromUtf8("score"));
        score->setMaximumSize(QSize(16777215, 50));

        gridLayout_2->addWidget(score, 2, 0, 1, 1);


        gridLayout->addWidget(widget, 0, 0, 1, 2);


        retranslateUi(change);

        QMetaObject::connectSlotsByName(change);
    } // setupUi

    void retranslateUi(QWidget *change)
    {
        change->setWindowTitle(QCoreApplication::translate("change", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        back->setText(QCoreApplication::translate("change", "\344\270\273\350\217\234\345\215\225", nullptr));
        stu_info->setText(QCoreApplication::translate("change", "\345\255\246\347\224\237\344\277\241\346\201\257", nullptr));
        consume->setText(QCoreApplication::translate("change", "\346\266\210\350\264\271\350\256\260\345\275\225", nullptr));
        score->setText(QCoreApplication::translate("change", "\346\210\220\347\273\251\344\277\241\346\201\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class change: public Ui_change {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGE_H
