/********************************************************************************
** Form generated from reading UI file 'billrecord.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BILLRECORD_H
#define UI_BILLRECORD_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_billrecord
{
public:
    QGridLayout *gridLayout_2;
    QTabWidget *tabWidget;
    QWidget *add;
    QGridLayout *gridLayout_3;
    QLabel *label_5;
    QLineEdit *ad_id;
    QLabel *label_6;
    QDateEdit *ad_date;
    QLabel *label_7;
    QLineEdit *ad_item;
    QLabel *label_8;
    QLineEdit *ad_charge;
    QPushButton *btn_add;
    QWidget *find;
    QGridLayout *gridLayout_4;
    QLabel *s_item;
    QLabel *label_12;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *s_date;
    QLineEdit *sear_id;
    QLabel *s_charge;
    QPushButton *btn_search;
    QWidget *change;
    QGridLayout *gridLayout;
    QLabel *label_4;
    QLineEdit *c_id;
    QLabel *label;
    QDateEdit *c_date;
    QLabel *label_2;
    QLineEdit *c_item;
    QLabel *label_3;
    QLineEdit *c_charge;
    QPushButton *btn_change;
    QPushButton *btn_delete;
    QPushButton *memu;

    void setupUi(QWidget *billrecord)
    {
        if (billrecord->objectName().isEmpty())
            billrecord->setObjectName(QString::fromUtf8("billrecord"));
        billrecord->resize(498, 390);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        billrecord->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(billrecord);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        tabWidget = new QTabWidget(billrecord);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        add = new QWidget();
        add->setObjectName(QString::fromUtf8("add"));
        gridLayout_3 = new QGridLayout(add);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_5 = new QLabel(add);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_5, 0, 0, 1, 1);

        ad_id = new QLineEdit(add);
        ad_id->setObjectName(QString::fromUtf8("ad_id"));
        ad_id->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(ad_id, 0, 1, 1, 1);

        label_6 = new QLabel(add);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_6, 1, 0, 1, 1);

        ad_date = new QDateEdit(add);
        ad_date->setObjectName(QString::fromUtf8("ad_date"));
        ad_date->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(ad_date, 1, 1, 1, 1);

        label_7 = new QLabel(add);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_7, 2, 0, 1, 1);

        ad_item = new QLineEdit(add);
        ad_item->setObjectName(QString::fromUtf8("ad_item"));
        ad_item->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(ad_item, 2, 1, 1, 1);

        label_8 = new QLabel(add);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_8, 3, 0, 1, 1);

        ad_charge = new QLineEdit(add);
        ad_charge->setObjectName(QString::fromUtf8("ad_charge"));
        ad_charge->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(ad_charge, 3, 1, 1, 1);

        btn_add = new QPushButton(add);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));
        btn_add->setMaximumSize(QSize(16777215, 30));

        gridLayout_3->addWidget(btn_add, 4, 1, 1, 1);

        tabWidget->addTab(add, QString());
        find = new QWidget();
        find->setObjectName(QString::fromUtf8("find"));
        gridLayout_4 = new QGridLayout(find);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        s_item = new QLabel(find);
        s_item->setObjectName(QString::fromUtf8("s_item"));
        s_item->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_item, 2, 1, 1, 1);

        label_12 = new QLabel(find);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_12, 3, 0, 1, 1);

        label_9 = new QLabel(find);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_9, 0, 0, 1, 1);

        label_10 = new QLabel(find);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_10, 1, 0, 1, 1);

        label_11 = new QLabel(find);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_11, 2, 0, 1, 1);

        s_date = new QLabel(find);
        s_date->setObjectName(QString::fromUtf8("s_date"));
        s_date->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_date, 1, 1, 1, 1);

        sear_id = new QLineEdit(find);
        sear_id->setObjectName(QString::fromUtf8("sear_id"));
        sear_id->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(sear_id, 0, 1, 1, 1);

        s_charge = new QLabel(find);
        s_charge->setObjectName(QString::fromUtf8("s_charge"));
        s_charge->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_charge, 3, 1, 1, 1);

        btn_search = new QPushButton(find);
        btn_search->setObjectName(QString::fromUtf8("btn_search"));
        btn_search->setMaximumSize(QSize(16777215, 30));

        gridLayout_4->addWidget(btn_search, 4, 1, 1, 1);

        tabWidget->addTab(find, QString());
        change = new QWidget();
        change->setObjectName(QString::fromUtf8("change"));
        gridLayout = new QGridLayout(change);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_4 = new QLabel(change);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_4, 0, 0, 1, 1);

        c_id = new QLineEdit(change);
        c_id->setObjectName(QString::fromUtf8("c_id"));
        c_id->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_id, 0, 1, 1, 1);

        label = new QLabel(change);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label, 1, 0, 1, 1);

        c_date = new QDateEdit(change);
        c_date->setObjectName(QString::fromUtf8("c_date"));
        c_date->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_date, 1, 1, 1, 1);

        label_2 = new QLabel(change);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        c_item = new QLineEdit(change);
        c_item->setObjectName(QString::fromUtf8("c_item"));
        c_item->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_item, 2, 1, 1, 1);

        label_3 = new QLabel(change);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_3, 3, 0, 1, 1);

        c_charge = new QLineEdit(change);
        c_charge->setObjectName(QString::fromUtf8("c_charge"));
        c_charge->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_charge, 3, 1, 1, 1);

        btn_change = new QPushButton(change);
        btn_change->setObjectName(QString::fromUtf8("btn_change"));
        btn_change->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(btn_change, 4, 0, 1, 2);

        btn_delete = new QPushButton(change);
        btn_delete->setObjectName(QString::fromUtf8("btn_delete"));
        btn_delete->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(btn_delete, 4, 2, 1, 1);

        tabWidget->addTab(change, QString());

        gridLayout_2->addWidget(tabWidget, 1, 2, 1, 1);

        memu = new QPushButton(billrecord);
        memu->setObjectName(QString::fromUtf8("memu"));
        memu->setMaximumSize(QSize(16777215, 30));

        gridLayout_2->addWidget(memu, 1, 3, 1, 1);


        retranslateUi(billrecord);

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(billrecord);
    } // setupUi

    void retranslateUi(QWidget *billrecord)
    {
        billrecord->setWindowTitle(QCoreApplication::translate("billrecord", "\346\266\210\350\264\271\350\256\260\345\275\225\347\263\273\347\273\237", nullptr));
        label_5->setText(QCoreApplication::translate("billrecord", "\347\274\226\345\217\267", nullptr));
        label_6->setText(QCoreApplication::translate("billrecord", "\346\266\210\350\264\271\346\227\266\351\227\264", nullptr));
        label_7->setText(QCoreApplication::translate("billrecord", "\351\241\271\347\233\256", nullptr));
        label_8->setText(QCoreApplication::translate("billrecord", "\351\207\221\351\242\235", nullptr));
        btn_add->setText(QCoreApplication::translate("billrecord", "\346\267\273\345\212\240", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(add), QCoreApplication::translate("billrecord", "\346\267\273\345\212\240\346\266\210\350\264\271\350\256\260\345\275\225", nullptr));
        s_item->setText(QCoreApplication::translate("billrecord", "NULL", nullptr));
        label_12->setText(QCoreApplication::translate("billrecord", "\351\207\221\351\242\235", nullptr));
        label_9->setText(QCoreApplication::translate("billrecord", "\347\274\226\345\217\267", nullptr));
        label_10->setText(QCoreApplication::translate("billrecord", "\346\266\210\350\264\271\346\227\266\351\227\264", nullptr));
        label_11->setText(QCoreApplication::translate("billrecord", "\351\241\271\347\233\256", nullptr));
        s_date->setText(QCoreApplication::translate("billrecord", "NULL", nullptr));
        s_charge->setText(QCoreApplication::translate("billrecord", "NULL", nullptr));
        btn_search->setText(QCoreApplication::translate("billrecord", "\346\237\245\350\257\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(find), QCoreApplication::translate("billrecord", "\346\237\245\350\257\242\346\266\210\350\264\271\350\256\260\345\275\225", nullptr));
        label_4->setText(QCoreApplication::translate("billrecord", "\347\274\226\345\217\267", nullptr));
        label->setText(QCoreApplication::translate("billrecord", "\346\266\210\350\264\271\346\227\266\351\227\264", nullptr));
        label_2->setText(QCoreApplication::translate("billrecord", "\351\241\271\347\233\256", nullptr));
        label_3->setText(QCoreApplication::translate("billrecord", "\351\207\221\351\242\235", nullptr));
        btn_change->setText(QCoreApplication::translate("billrecord", "\344\277\256\346\224\271", nullptr));
        btn_delete->setText(QCoreApplication::translate("billrecord", "\345\210\240\351\231\244", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(change), QCoreApplication::translate("billrecord", "\344\277\256\346\224\271\346\266\210\350\264\271\350\256\260\345\275\225", nullptr));
        memu->setText(QCoreApplication::translate("billrecord", "\344\270\273\350\217\234\345\215\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class billrecord: public Ui_billrecord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BILLRECORD_H
