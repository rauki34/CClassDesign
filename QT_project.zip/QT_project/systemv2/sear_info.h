#ifndef SEAR_INFO_H
#define SEAR_INFO_H

#include <QWidget>
#include <QtDebug>
#include <QFile>
#include <QVector>
#include <QMessageBox>

namespace Ui {
class sear_info;
}

class sear_info : public QWidget
{
    Q_OBJECT

public:
    explicit sear_info(QWidget *parent = nullptr);
    ~sear_info();

private slots:
    void on_btn_search_clicked();

    void on_back_clicked();

private:
    Ui::sear_info *ui;
};

#endif // SEAR_INFO_H
