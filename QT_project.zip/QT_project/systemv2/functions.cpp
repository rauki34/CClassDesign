#include "functions.h"
#include "ui_functions.h"
#include "newstu.h"
#include "change.h"
#include "search.h"

functions::functions(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::functions)
{
    ui->setupUi(this);
}

functions::~functions()
{
    delete ui;
}
//（忘记重命名了www删干净头文件库太麻烦了）退出系统按钮
void functions::on_changeinf_2_clicked()
{
    exit(0);
}

//添加学生
void functions::on_addstu_clicked()
{
    newstu *w = new newstu();
    w->show();
    this->hide();
}

//查找学生
void functions::on_search_clicked()
{
    search *w = new search();
    w->show();
    this->hide();
}

//修改信息
void functions::on_changeinf_clicked()
{
    change *w = new change;
    w->show();
    this->hide();
}

