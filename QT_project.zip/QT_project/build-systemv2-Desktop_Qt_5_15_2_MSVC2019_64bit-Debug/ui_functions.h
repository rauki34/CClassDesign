/********************************************************************************
** Form generated from reading UI file 'functions.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FUNCTIONS_H
#define UI_FUNCTIONS_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_functions
{
public:
    QGridLayout *gridLayout;
    QPushButton *addstu;
    QPushButton *search;
    QPushButton *changeinf;
    QPushButton *changeinf_2;

    void setupUi(QWidget *functions)
    {
        if (functions->objectName().isEmpty())
            functions->setObjectName(QString::fromUtf8("functions"));
        functions->resize(553, 422);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        functions->setWindowIcon(icon);
        gridLayout = new QGridLayout(functions);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        addstu = new QPushButton(functions);
        addstu->setObjectName(QString::fromUtf8("addstu"));
        addstu->setMaximumSize(QSize(16777215, 60));

        gridLayout->addWidget(addstu, 0, 0, 1, 1);

        search = new QPushButton(functions);
        search->setObjectName(QString::fromUtf8("search"));
        search->setMaximumSize(QSize(16777215, 60));

        gridLayout->addWidget(search, 1, 0, 1, 1);

        changeinf = new QPushButton(functions);
        changeinf->setObjectName(QString::fromUtf8("changeinf"));
        changeinf->setMaximumSize(QSize(16777215, 60));

        gridLayout->addWidget(changeinf, 2, 0, 1, 1);

        changeinf_2 = new QPushButton(functions);
        changeinf_2->setObjectName(QString::fromUtf8("changeinf_2"));
        changeinf_2->setMaximumSize(QSize(16777215, 60));

        gridLayout->addWidget(changeinf_2, 3, 0, 1, 1);


        retranslateUi(functions);

        QMetaObject::connectSlotsByName(functions);
    } // setupUi

    void retranslateUi(QWidget *functions)
    {
        functions->setWindowTitle(QCoreApplication::translate("functions", "\344\270\273\350\217\234\345\215\225", nullptr));
        addstu->setText(QCoreApplication::translate("functions", "\346\267\273\345\212\240\345\255\246\347\224\237", nullptr));
        search->setText(QCoreApplication::translate("functions", "\346\237\245\350\257\242\345\255\246\347\224\237", nullptr));
        changeinf->setText(QCoreApplication::translate("functions", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        changeinf_2->setText(QCoreApplication::translate("functions", "\351\200\200\345\207\272\347\263\273\347\273\237", nullptr));
    } // retranslateUi

};

namespace Ui {
    class functions: public Ui_functions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FUNCTIONS_H
