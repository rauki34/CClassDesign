#include "supersocre.h"
#include "ui_supersocre.h"
#include "functions.h"
#include "gpa.h"


//supersocre 拼错了但是删ui改.h太麻烦了（已经删过一次了因为score的重合的问题）
supersocre::supersocre(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::supersocre)
{
    ui->setupUi(this);
}

supersocre::~supersocre()
{
    delete ui;
}

//返回主菜单
void supersocre::on_memu_clicked()
{
    functions *w = new functions;
    w->show();
    this->hide();
}

//添加成绩
void supersocre::on_btn_add_clicked()
{
    QString name = ui->a_name->text();
    QString id = ui->a_id->text();
    QString subject = ui->a_subject->text();
    QString score = ui->a_score->text();
    if(ui->a_name->text() == "" || ui->a_id->text() == "" || ui->a_subject->text() == "" || ui->a_score->text() == ""){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QFile file("score.txt");
    //实例化一个QFile file为我们的数据文件score.txt
    file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Append);
    //open()可以用来打开文件这里QIODevice::WriteOnly代表将文件以只写的方式打开
    //QIODevice::Text代表我们打开的是文本文件，QIODevice::Text会对end-of-line结束符进行转译
    //QIODevice::Append以追加的方式打开，新增加的内容将被追加到文件末尾
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    QTextStream out(&file);
    //QTextStream可以进行一些基本的文本读写，比如QString int char之类的数据QDataStream可以进行一个如QMap QPoint之类数据的读写。
    out << name << " " <<  id << " " << subject << " " << score << endl;
    //将我们刚刚获取的数据写入文件
    file.close();
    QMessageBox::about(this, "反馈", "插入成功");
    supersocre *w = new supersocre;
    w->show();
    this->hide();
}

//查询成绩
void supersocre::on_pushButton_clicked()
{
    if(ui->s_id->text() == "" || ui->s_subject->text() == ""){
        QMessageBox::about(this, "警告", "存在空项");
        return;
    }
    QFile file("score.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<GPA> gpaw;
    //数据类型为BillCore的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString name,id,subject,score;
        inp >> name >> id >>  subject >> score;
        gpaw.push_back(GPA(name,id,subject,score));
        //调用之前建立的构造函数实例化一个GPA对象并将其加入gpaw
    }
    gpaw.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString id = ui->s_id->text();
    QString subject = ui->s_subject->text();
    bool flag = false;
    for(auto i : gpaw){
        if(i.getId() == id && i.getSubject() == subject){
            ui->s_name->setText(i.getName());
            ui->s_score->setText(i.getScore());
            flag = true;
            break;
        }
    }
    if(!flag){
        QMessageBox::about(this, "反馈", "成绩不存在！");
    }
    ui->s_id->clear();
    ui->s_subject->clear();
}

//修改成绩
void supersocre::on_btn_change_clicked()
{
    if(ui->c_name->text() == "" || ui->c_id->text() == "" || ui->c_subject->text() == "" || ui->c_score->text() == ""){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QFile file("score.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<GPA> gpaw;
    //数据类型为BillCore的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString name,id,subject,score;
        inp >> name >> id >>  subject >> score;
        gpaw.push_back(GPA(name,id,subject,score));
        //调用之前建立的构造函数实例化一个GPA对象并将其加入gpaw
    }
    gpaw.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString name = ui->c_name->text();
    QString id = ui->c_id->text();
    QString subject = ui->c_subject->text();
    QString score = ui->c_score->text();
    bool flag = false;
    for(QVector<GPA>::iterator it = gpaw.begin(); it != gpaw.end(); it++){
        if(it->getId() == id && it->getSubject() == subject){
            it->setName(name);
            it->setScore(score);
            flag = true;
        }
    }
    if(flag){   //如果进行过修改，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "修改成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : gpaw){
            out << i.getName() << " " << i.getId() << " " << i.getSubject() << " " << i.getScore() << endl;
        }
        file.close();
    }else{
        //如果没有进行修改，弹出不存在对话框
        QMessageBox::about(this, "反馈", "成绩不存在！");
    }
    //关闭文件
    supersocre *w = new supersocre;
    w->show();
    this->hide();
    //初始化
}

//删除成绩
void supersocre::on_btn_delete_clicked()
{
    QVector<GPA> gpaw;
    if(ui->c_id->text() == "" || ui->c_subject->text() == ""){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "警告", "学号和科目不得为空！ ");
        return;
    }
    QFile file("score.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    while(!inp.atEnd()){ //读到文件结尾
        QString name,id,subject,score;
        inp >> name >> id >>  subject >> score;
        gpaw.push_back(GPA(name,id,subject,score));
        //调用之前建立的构造函数实例化一个GPA对象并将其加入gpaw
    }
    gpaw.pop_back();
    //扔掉最后的无用数据
    file.close();
    QString id = ui->c_id->text();
    QString subject = ui->c_subject->text();
    bool flag = false;
    for(QVector<GPA>::iterator it = gpaw.begin(); it != gpaw.end(); it++){
        if(it->getId() == id && it->getSubject() == subject){
            gpaw.erase(it);//迭代器遍历gpaw找到对应就删除
            flag = true;
        }
    }
    if(flag){   //如果进行过修改，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "删除成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : gpaw){
            out << i.getName() << " " << i.getId() << " " << i.getSubject() << " " << i.getScore() << endl;
        }
        file.close();
    }else{
        //如果没有进行删除，弹出不存在对话框
        QMessageBox::about(this, "反馈", "成绩不存在！");
    }
    ui->c_id->clear();
    ui->c_subject->clear();
}

