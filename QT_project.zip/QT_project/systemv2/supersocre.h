#ifndef SUPERSOCRE_H
#define SUPERSOCRE_H

#include <QWidget>
#include <QMessageBox>
#include <QtDebug>
#include <QFile>
#include <QDateEdit>
#include <QComboBox>
#include <QString>

namespace Ui {
class supersocre;
}

class supersocre : public QWidget
{
    Q_OBJECT

public:
    explicit supersocre(QWidget *parent = nullptr);
    ~supersocre();

private slots:
    void on_memu_clicked();

    void on_btn_add_clicked();

    void on_pushButton_clicked();

    void on_btn_change_clicked();

    void on_btn_delete_clicked();

private:
    Ui::supersocre *ui;
};

#endif // SUPERSOCRE_H
