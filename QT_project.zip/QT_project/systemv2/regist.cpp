#include "regist.h"
#include "ui_regist.h"
#include "memu.h"
#include <QString>
#include <QMessageBox>

regist::regist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);
}

regist::~regist()
{
    delete ui;
}
//注册用户信息
void regist::on_regis_clicked()
{
    QString str1 = ui->passw1->text();
    QString str2 = ui->passw2->text();
    //判断两次密码是否相同
    int i = QString::compare(str1,str2);
    if(i){
        QMessageBox::about(this,"警告","两次密码输入不同");
        return;
    }
    //密码个数报错
    QString str = ui->passw1->text();
    if(str.length()<8){
        QMessageBox::about(this,"警告","密码个数不符");
        return;
    }
    QFile file("account.txt");
    //实例化一个QFile file为我们的数据文件account.txt
    file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Append);
    //open()可以用来打开文件这里QIODevice::WriteOnly代表将文件以只写的方式打开
    //QIODevice::Text代表我们打开的是文本文件，QIODevice::Text会对end-of-line结束符进行转译
    //QIODevice::Append以追加的方式打开，新增加的内容将被追加到文件末尾
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    QTextStream out(&file);
    //QTextStream可以进行一些基本的文本读写，比如QString int char之类的数据QDataStream可以进行一个如QMap QPoint之类数据的读写。
    QString account = ui->username->text();
    //取出账号信息
    out << account << " " <<  str1 << "\n";
    //将我们刚刚获取的数据写入文件
    file.close();
    QMessageBox::about(this, "反馈", "注册成功");
    //注册完成跳转到登录窗口
    memu *w = new memu();
    w->show();
    this->hide();
}

//返回登录界面
void regist::on_bcak_clicked()
{
    memu *w = new memu();
    w->show();
    this->hide();
}

