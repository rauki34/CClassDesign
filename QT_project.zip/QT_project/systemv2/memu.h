#ifndef MEMU_H
#define MEMU_H

#include <QWidget>
#include <QtDebug>
#include <QString>
#include <QFile>
#include <QVector>
#include <QMessageBox>

namespace Ui {
class memu;
}

class memu : public QWidget
{
    Q_OBJECT

public:
    explicit memu(QWidget *parent = nullptr);
    ~memu();

private slots:
    void on_btn_login_clicked();
    void on_btn_regis_clicked();

    void on_checkBox_clicked(bool checked);

private:
    Ui::memu *ui;
};

#endif // MEMU_H
