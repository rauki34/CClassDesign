/********************************************************************************
** Form generated from reading UI file 'score.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCORE_H
#define UI_SCORE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_score
{
public:
    QGridLayout *gridLayout_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_3;
    QLabel *label_9;
    QLineEdit *a_name;
    QLabel *label_10;
    QLineEdit *a_id;
    QLabel *label_11;
    QLineEdit *a_subject;
    QLabel *label_12;
    QLineEdit *a_socre;
    QPushButton *btn_add;
    QWidget *tab_2;
    QGridLayout *gridLayout_4;
    QLabel *label_13;
    QLabel *label_6;
    QLabel *s_name;
    QLabel *label_8;
    QLabel *s_socre;
    QLineEdit *s_subject;
    QLineEdit *s_id;
    QLabel *label_7;
    QPushButton *pushButton;
    QWidget *tab_3;
    QGridLayout *gridLayout;
    QLineEdit *c_subject;
    QLineEdit *c_id;
    QLabel *label_3;
    QPushButton *btn_change;
    QLabel *label;
    QLineEdit *c_name;
    QLabel *label_4;
    QLineEdit *c_score;
    QLabel *label_2;
    QPushButton *btn_delete;
    QPushButton *memu;

    void setupUi(QWidget *score)
    {
        if (score->objectName().isEmpty())
            score->setObjectName(QString::fromUtf8("score"));
        score->resize(518, 456);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/8285adeddd84c7ae8819edca513869b1857cd599.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        score->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(score);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        tabWidget = new QTabWidget(score);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_3 = new QGridLayout(tab);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_9 = new QLabel(tab);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_9, 0, 0, 1, 1);

        a_name = new QLineEdit(tab);
        a_name->setObjectName(QString::fromUtf8("a_name"));
        a_name->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(a_name, 0, 1, 1, 1);

        label_10 = new QLabel(tab);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_10, 1, 0, 1, 1);

        a_id = new QLineEdit(tab);
        a_id->setObjectName(QString::fromUtf8("a_id"));
        a_id->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(a_id, 1, 1, 1, 1);

        label_11 = new QLabel(tab);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_11, 2, 0, 1, 1);

        a_subject = new QLineEdit(tab);
        a_subject->setObjectName(QString::fromUtf8("a_subject"));
        a_subject->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(a_subject, 2, 1, 1, 1);

        label_12 = new QLabel(tab);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(label_12, 3, 0, 1, 1);

        a_socre = new QLineEdit(tab);
        a_socre->setObjectName(QString::fromUtf8("a_socre"));
        a_socre->setMaximumSize(QSize(16777215, 50));

        gridLayout_3->addWidget(a_socre, 3, 1, 1, 1);

        btn_add = new QPushButton(tab);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));
        btn_add->setMaximumSize(QSize(16777215, 30));

        gridLayout_3->addWidget(btn_add, 4, 1, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout_4 = new QGridLayout(tab_2);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        label_13 = new QLabel(tab_2);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_13, 0, 0, 1, 1);

        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_6, 3, 0, 1, 1);

        s_name = new QLabel(tab_2);
        s_name->setObjectName(QString::fromUtf8("s_name"));
        s_name->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_name, 2, 1, 1, 1);

        label_8 = new QLabel(tab_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_8, 1, 0, 1, 1);

        s_socre = new QLabel(tab_2);
        s_socre->setObjectName(QString::fromUtf8("s_socre"));
        s_socre->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_socre, 3, 1, 1, 1);

        s_subject = new QLineEdit(tab_2);
        s_subject->setObjectName(QString::fromUtf8("s_subject"));
        s_subject->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_subject, 1, 1, 1, 1);

        s_id = new QLineEdit(tab_2);
        s_id->setObjectName(QString::fromUtf8("s_id"));
        s_id->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(s_id, 0, 1, 1, 1);

        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMaximumSize(QSize(16777215, 50));

        gridLayout_4->addWidget(label_7, 2, 0, 1, 1);

        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(16777215, 30));

        gridLayout_4->addWidget(pushButton, 4, 1, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        gridLayout = new QGridLayout(tab_3);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        c_subject = new QLineEdit(tab_3);
        c_subject->setObjectName(QString::fromUtf8("c_subject"));
        c_subject->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_subject, 2, 1, 1, 1);

        c_id = new QLineEdit(tab_3);
        c_id->setObjectName(QString::fromUtf8("c_id"));
        c_id->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_id, 1, 1, 1, 1);

        label_3 = new QLabel(tab_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        btn_change = new QPushButton(tab_3);
        btn_change->setObjectName(QString::fromUtf8("btn_change"));
        btn_change->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(btn_change, 4, 1, 1, 1);

        label = new QLabel(tab_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        c_name = new QLineEdit(tab_3);
        c_name->setObjectName(QString::fromUtf8("c_name"));
        c_name->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_name, 0, 1, 1, 1);

        label_4 = new QLabel(tab_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        c_score = new QLineEdit(tab_3);
        c_score->setObjectName(QString::fromUtf8("c_score"));
        c_score->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(c_score, 3, 1, 1, 1);

        label_2 = new QLabel(tab_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 50));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        btn_delete = new QPushButton(tab_3);
        btn_delete->setObjectName(QString::fromUtf8("btn_delete"));
        btn_delete->setMaximumSize(QSize(16777215, 30));

        gridLayout->addWidget(btn_delete, 4, 2, 1, 1);

        tabWidget->addTab(tab_3, QString());

        gridLayout_2->addWidget(tabWidget, 0, 0, 1, 1);

        memu = new QPushButton(score);
        memu->setObjectName(QString::fromUtf8("memu"));
        memu->setMaximumSize(QSize(16777215, 30));

        gridLayout_2->addWidget(memu, 0, 1, 1, 1);


        retranslateUi(score);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(score);
    } // setupUi

    void retranslateUi(QWidget *score)
    {
        score->setWindowTitle(QCoreApplication::translate("score", "\346\210\220\347\273\251\347\263\273\347\273\237", nullptr));
        label_9->setText(QCoreApplication::translate("score", "\345\247\223\345\220\215", nullptr));
        label_10->setText(QCoreApplication::translate("score", "\345\255\246\345\217\267", nullptr));
        label_11->setText(QCoreApplication::translate("score", "\347\247\221\347\233\256", nullptr));
        label_12->setText(QCoreApplication::translate("score", "\346\210\220\347\273\251", nullptr));
        btn_add->setText(QCoreApplication::translate("score", "\346\267\273\345\212\240", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("score", "\346\267\273\345\212\240\346\210\220\347\273\251", nullptr));
        label_13->setText(QCoreApplication::translate("score", "\345\255\246\345\217\267", nullptr));
        label_6->setText(QCoreApplication::translate("score", "\346\210\220\347\273\251", nullptr));
        s_name->setText(QCoreApplication::translate("score", "NULL", nullptr));
        label_8->setText(QCoreApplication::translate("score", "\347\247\221\347\233\256", nullptr));
        s_socre->setText(QCoreApplication::translate("score", "NULL", nullptr));
        label_7->setText(QCoreApplication::translate("score", "\345\247\223\345\220\215", nullptr));
        pushButton->setText(QCoreApplication::translate("score", "\346\237\245\350\257\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("score", "\346\237\245\350\257\242\346\210\220\347\273\251", nullptr));
        label_3->setText(QCoreApplication::translate("score", "\347\247\221\347\233\256", nullptr));
        btn_change->setText(QCoreApplication::translate("score", "\344\277\256\346\224\271", nullptr));
        label->setText(QCoreApplication::translate("score", "\345\247\223\345\220\215", nullptr));
        label_4->setText(QCoreApplication::translate("score", "\346\210\220\347\273\251", nullptr));
        label_2->setText(QCoreApplication::translate("score", "\345\255\246\345\217\267", nullptr));
        btn_delete->setText(QCoreApplication::translate("score", "\345\210\240\351\231\244", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("score", "\344\277\256\346\224\271\346\210\220\347\273\251", nullptr));
        memu->setText(QCoreApplication::translate("score", "\344\270\273\350\217\234\345\215\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class score: public Ui_score {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCORE_H
