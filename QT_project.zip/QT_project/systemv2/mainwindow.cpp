#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "memu.h"
#include "functions.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

//退出系统
void MainWindow::on_pushButton_clicked()
{
    exit(0);
}

//转到功能选择主菜单
void MainWindow::on_linkstart_clicked()
{
    functions *w = new functions();
    w->show();
    this->hide();
}

