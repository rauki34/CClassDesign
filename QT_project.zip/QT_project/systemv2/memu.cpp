#include "memu.h"
#include "mainwindow.h"
#include "ui_memu.h"
#include "regist.h"
#include <QString>
#include <QMessageBox>
#include "account.h"

memu::memu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::memu)
{
    ui->setupUi(this);
}

memu::~memu()
{
    delete ui;
}
//登录(查找账户和密码）
void memu::on_btn_login_clicked()
{
   //失败发送提示
    if(ui->user->text() == ""||ui->password->text() == ""){
        QMessageBox::about(this, "警告", "用户名或密码不能为空");
        return;
    }
    QFile file("account.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<Account> acer;
    //数据类型为Account的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString user,password;
        inp >> user >> password;
        acer.push_back(Account(user, password));
        //调用之前建立的构造函数实例化一个Account对象并将其加入acer
    }
    acer.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString user = ui->user->text();
    QString password = ui->password->text();
    bool flag = false;
    for(auto i : acer){
        if((i.getUser() == user) && (i.getPassword() == password))
        {
            flag = true;
            //成功进入主界面
            MainWindow *w = new MainWindow();
            w->show();
            this->hide();
        }
     }
    if(!flag){
        QMessageBox::about(this, "反馈", "用户名或密码错误!");
    }

    ui->user->clear();
    ui->password->clear();
}

//注册账户
void memu::on_btn_regis_clicked()
{
    regist *w = new regist();
    w->show();
    this->hide();
}

//密码显示
void memu::on_checkBox_clicked(bool checked)
{
    if(checked){
        ui->password->setEchoMode(QLineEdit::Normal);
    }//显示  Normal, NoEcho, Password, PasswordEchoOnEdit
    else{
        ui->password->setEchoMode(QLineEdit::Password);
    }//密文
}

