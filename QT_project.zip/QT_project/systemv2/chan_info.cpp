#include "chan_info.h"
#include "ui_chan_info.h"
#include "change.h"

chan_info::chan_info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chan_info)
{
    ui->setupUi(this);
}

chan_info::~chan_info()
{
    delete ui;
}
//返回
void chan_info::on_back_clicked()
{
    change *w = new change;
    w->show();
    this->hide();
}

//修改
void chan_info::on_change_clicked()
{
    if(ui->name->text() == "" || ui->code->text() == "" || ui->major->text() == ""||ui->hobby->text() == ""){
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QVector<StudentInfo> allStudentInfo;    //数据类型为StudentInfo的QVector容器
    QFile file("student.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    //QIODevice::Truncate在写入时会从文件开始处写入，覆盖原有内容
    QTextStream inp(&file);
    //以file建立一个QT的文本流
    while(!inp.atEnd()){
        QString name,code,major,gender,birth,hobby;
        inp >> name >> code >> major >> gender >> birth >> hobby;
        //读入各项信息
        allStudentInfo.push_back(StudentInfo(name, code, hobby, birth, gender, major));
        //调用之前建立的构造函数实例化一个StudentInfo对象并将其加入allStudentInfo
    }
    allStudentInfo.pop_back();  //文件最后会多读一个无用数据，将其拿出
    file.close();
    QString code = ui->code->text();
    QString name = ui->name->text();
    QString gender = ui->gender->currentText();
    QString major = ui->major->text();
    QString birth = ui->date->text();
    QString hobby = ui->hobby->text();
    bool flag = false;
    for(QVector<StudentInfo>::iterator it = allStudentInfo.begin(); it != allStudentInfo.end(); it++){
        if(it->getCode() == code){
            it->setName(name);
            it->setGender(gender);
            it->setMajor(major);
            it->setBirth(birth);
            it->setHobby(hobby);
            flag = true;
        }
    }
    if(flag){   //如果进行过修改，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "修改成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : allStudentInfo){
            out << i.getName() << " " << i.getCode() << " " << i.getMajor() << " " << i.getGender() << " " << i.getBirth() << " " << i.getHobby() << endl;
        }
        file.close();
    }else{
        //如果没有进行修改，弹出不存在对话框
        QMessageBox::about(this, "反馈", "学号不存在！");
    }
    //关闭文件
    chan_info *w = new chan_info;
    w->show();
    this->hide();
    //初始化
}

//删除
void chan_info::on_delete_2_clicked()
{
    QVector<StudentInfo> allStudentInfo;    //数据类型为StudentInfo的QVector容器
    if(ui->code->text() == ""){   //如果code输入栏为空则输出错误提示并返回
        QMessageBox::about(this, "反馈", "学号不得为空!");
        return;
    }
    QFile file("student.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    //QIODevice::Truncate在写入时会从文件开始处写入，覆盖原有内容
    QTextStream inp(&file);
    //以file建立一个QT的文本流
    while(!inp.atEnd()){
        QString name,code,major,gender,birth,hobby;
        inp >> name >> code >> major >> gender >> birth >> hobby;
        //读入各项信息
        allStudentInfo.push_back(StudentInfo(name, code, hobby, birth, gender, major));
        //调用之前建立的构造函数实例化一个StudentInfo对象并将其加入allStudentInfo
    }
    allStudentInfo.pop_back();  //文件最后会多读一个无用数据，将其拿出
    file.close();
    QString code = ui->code->text();
    //获取用户输入的学号
    bool flag = false;
    //记录是否进行过删除
    for(QVector<StudentInfo>::iterator it = allStudentInfo.begin(); it != allStudentInfo.end(); it++){
        //用迭代器遍历allStudentInfo
        if(it->getCode() == code){  //如果找到有学号与输入学号相同的学生，就进行删除
            allStudentInfo.erase(it);
            flag = true;
        }
    }
    if(flag){   //如果进行过删除，弹出对话框并更新文件
        QMessageBox::about(this, "反馈", "删除成功");
        file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Truncate);
        //以只写覆盖的方式打开文本文件
        if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
            QMessageBox::about(this, "反馈", "数据文件打开失败");
            return;
        }
        QTextStream out(&file);
        for(auto i : allStudentInfo){
            out << i.getName() << " " << i.getCode() << " " << i.getMajor() << " " << i.getGender() << " " << i.getBirth() << " " << i.getHobby() << endl;
        }
        file.close();
    }else{
        //如果没有进行删除，弹出不存在对话框
        QMessageBox::about(this, "反馈", "学号不存在！");
    }
    //关闭文件
    ui->code->clear();
    //清空id输入框
}

