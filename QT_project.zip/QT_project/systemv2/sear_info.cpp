#include "sear_info.h"
#include "ui_sear_info.h"
#include "search.h"
#include "studentinfo.h"

sear_info::sear_info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sear_info)
{
    ui->setupUi(this);
}

sear_info::~sear_info()
{
    delete ui;
}
//查询信息
void sear_info::on_btn_search_clicked()
{
    if(ui->lineEdit->text() == ""){
        QMessageBox::about(this, "警告", "学号不能为空");
        return;
    }
    QFile file("student.txt");
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    //以只读的方式打开文本文件
    if(!file.isOpen()){ //文件打开失败
        QMessageBox::about(this, "反馈", "文件打开失败");
        return;
    }
    QTextStream inp(&file);
    //以file作为Qt文本流
    QVector<StudentInfo> allStudentInfo;
    //数据类型为StudentInfo的QVector容器
    while(!inp.atEnd()){ //读到文件结尾
        QString name, code, gender, major, birth, hobby;
        inp >> name >> code >>  major >> gender >> birth >> hobby;
        allStudentInfo.push_back(StudentInfo(name, code, hobby, birth, gender, major));
        //allStudentInfo.push_back(1);
        //调用之前建立的构造函数实例化一个StudentInfo对象并将其加入allStudentInfo
    }
    allStudentInfo.pop_back();
    //扔掉最后的无用数据
    file.close();
    //关闭文件
    QString code = ui->lineEdit->text();
    bool flag = false;
    for(auto i : allStudentInfo){
        if(i.getCode() == code){
            ui->showname->setText(i.getName());
            ui->showbirth->setText(i.getBirth());
            ui->showgender->setText(i.getGender());
            ui->showmajor->setText(i.getMajor());
            ui->showhobby->setText(i.getHobby());
            flag = true;
            break;
        }
    }
    if(!flag){
        QMessageBox::about(this, "反馈", "学号不存在！");
    }
    ui->lineEdit->clear();
}


//返回查找界面
void sear_info::on_back_clicked()
{
    search *w = new search;
    w->show();
    this->hide();
}

