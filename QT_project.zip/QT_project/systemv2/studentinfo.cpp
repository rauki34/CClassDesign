#include "studentinfo.h"

StudentInfo::StudentInfo()
{

}
