#ifndef BILLCORE_H
#define BILLCORE_H
#include <QString>

class BillCore
{
private: QString id,date,item,charge;
public:
    BillCore();
    BillCore(QString tid,QString tdate,QString titem, QString tcharge){
        id = tid;
        date = tdate;
        item = titem;
        charge = tcharge;
    }
    QString getId(){
        return id;
    }
    QString getDate(){
        return date;
    }
    QString getItem(){
        return item;
    }
    QString getCharge(){
        return charge;
    }
    void setId(QString tid){
        id = tid;
    }
    void setDate(QString tdate){
        date = tdate;
    }
    void setItem(QString titem){
        item = titem;
    }
    void setCharge(QString tcharge){
        charge = tcharge;
    }
};

#endif // BILLCORE_H
