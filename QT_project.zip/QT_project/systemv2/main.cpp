#include "mainwindow.h"
#include "memu.h"
#include "regist.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    memu w;
    w.show();
    return a.exec();
}
