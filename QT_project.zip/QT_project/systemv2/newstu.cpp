#include "newstu.h"
#include "ui_newstu.h"
#include "functions.h"
newstu::newstu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newstu)
{
    ui->setupUi(this);
}

newstu::~newstu()
{
    delete ui;
}
//返回主菜单
void newstu::on_back_clicked()
{
    functions *w = new functions();
    w->show();
    this->hide();
}

//添加信息到库
void newstu::on_addnew_clicked()
{
    QString name = ui->name->text();
     //将用户输入的姓名由nameLineEdit取出
    QString code = ui->code->text();
    //将用户输入的学号由codeLineEdit取出
    QString major = ui->major->text();
        //将用户输入的专业由majorLineEdit取出
    QString gender = ui->gender->currentText();
    //将用户选择的信息从gender里面取出
    QString date = ui->date->text();
   // QString dateString = date.toString("yyyy-MM-dd");好像不用
    //将dateEdit里的日期取出
    QString hobby = ui->hobby->text();
    //取出爱好
    if(ui->name->text() == "" || ui->code->text() == "" || ui->major->text() == ""||ui->hobby->text() == "" ){
        //插入项数据都不能为空，否则在读取文件时会出现问题。
        QMessageBox::about(this, "反馈", "存在空项");
        return;
    }
    QFile file("student.txt");
    //实例化一个QFile file为我们的数据文件student.txt
    file.open(QIODevice::WriteOnly|QIODevice::Text|QIODevice::Append);
    //open()可以用来打开文件这里QIODevice::WriteOnly代表将文件以只写的方式打开
    //QIODevice::Text代表我们打开的是文本文件，QIODevice::Text会对end-of-line结束符进行转译
    //QIODevice::Append以追加的方式打开，新增加的内容将被追加到文件末尾
    if(!file.isOpen()){ //如果数据文件没有打开，弹出对话框提示用户
        QMessageBox::about(this, "反馈", "数据文件打开失败");
        return;
    }
    QTextStream out(&file);
    //QTextStream可以进行一些基本的文本读写，比如QString int char之类的数据QDataStream可以进行一个如QMap QPoint之类数据的读写。
    out << name << " " <<  code << " " << major << " " << gender <<" "<< date <<" "<< hobby << endl;
    //将我们刚刚获取的数据写入文件
    file.close();
    QMessageBox::about(this, "反馈", "插入成功");
    //直接开新窗口doge
    newstu *w = new newstu;
    w->show();
    this->close();
    /*ui->name->clear();
    ui->code->clear();
    ui->major->clear();
    ui->hobby->clear();
    //将用户输入的数据清空
    直接开新窗口呗（天才！
    //date和gender项暂时没有想到好的初始化方案（反正有选项先不管bushi*/
}

